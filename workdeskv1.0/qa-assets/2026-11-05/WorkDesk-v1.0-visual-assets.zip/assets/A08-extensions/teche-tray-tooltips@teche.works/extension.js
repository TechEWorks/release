import Clutter from 'gi://Clutter';
import GLib from 'gi://GLib';
import St from 'gi://St';

import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import {Extension} from 'resource:///org/gnome/shell/extensions/extension.js';

const LABELS = [
    [/network|ethernet|wired|wifi|wireless|signal/i, 'Network'],
    [/audio|volume|speaker|sound/i, 'Sound'],
    [/power|shutdown|battery/i, 'Power'],
];

export default class WorkDeskStatusTooltips extends Extension {
    enable() {
        this._pending = 0;
        this._current = null;
        this._icons = [];
        this._tooltip = new St.Label({
            style_class: 'teche-status-tooltip',
            text: '',
            visible: false,
            reactive: false,
        });
        this._tooltip.set_style('background-color: #252932; color: #f5f6f8; ' +
            'border: 1px solid #637084; border-radius: 2px; ' +
            'padding: 5px 9px; font-size: 12pt;');
        Main.layoutManager.addTopChrome(this._tooltip);

        this._button = Main.panel.statusArea.quickSettings;
        const indicators = this._button?._indicators;
        if (!indicators) {
            console.warn('TechE status tooltips: GNOME Quick Settings unavailable');
            return;
        }
        const scan = actor => {
            if (actor instanceof St.Icon && actor.visible) {
                const name = actor.icon_name ?? actor.gicon?.to_string() ?? '';
                const match = LABELS.find(([pattern]) => pattern.test(name));
                if (match)
                    this._icons.push({actor, label: match[1]});
            }
            for (const child of actor.get_children())
                scan(child);
        };
        scan(indicators);
        this._motionId = this._button.connect('motion-event', () => {
            this._onMotion();
            return Clutter.EVENT_PROPAGATE;
        });
        this._leaveId = this._button.connect('leave-event', () => {
            this._hide();
            return Clutter.EVENT_PROPAGATE;
        });
        this._clickId = this._button.connect('button-press-event', () => {
            this._hide();
            return Clutter.EVENT_PROPAGATE;
        });
        console.log(`TechE status tooltips: attached ${this._icons.length} icons`);
    }

    _onMotion() {
        const [pointerX] = global.get_pointer();
        let nearest = null;
        let distance = Infinity;
        for (const item of this._icons) {
            if (!item.actor.visible)
                continue;
            const [x] = item.actor.get_transformed_position();
            const [width] = item.actor.get_transformed_size();
            const delta = Math.abs(pointerX - x - width / 2);
            if (delta < distance) {
                nearest = item;
                distance = delta;
            }
        }
        if (!nearest || nearest === this._current)
            return;
        this._hide();
        this._current = nearest;
        this._pending = GLib.timeout_add(GLib.PRIORITY_DEFAULT, 450, () => {
            this._pending = 0;
            if (this._current !== nearest || !nearest.actor.visible)
                return GLib.SOURCE_REMOVE;
            this._tooltip.text = nearest.label;
            this._tooltip.show();
            const [x, y] = nearest.actor.get_transformed_position();
            const [width] = nearest.actor.get_transformed_size();
            const tooltipWidth = this._tooltip.get_width();
            const tooltipHeight = this._tooltip.get_height();
            const desiredX = Math.round(x + width / 2 - tooltipWidth / 2);
            this._tooltip.set_position(
                Math.max(4, Math.min(desiredX,
                    global.stage.width - tooltipWidth - 4)),
                Math.max(0, Math.round(y - tooltipHeight - 10)));
            return GLib.SOURCE_REMOVE;
        });
    }

    _hide() {
        if (this._pending) {
            GLib.Source.remove(this._pending);
            this._pending = 0;
        }
        this._current = null;
        this._tooltip?.hide();
    }

    disable() {
        this._hide();
        if (this._button && this._motionId) {
            this._button.disconnect(this._motionId);
            this._button.disconnect(this._leaveId);
            this._button.disconnect(this._clickId);
        }
        this._icons = [];
        this._button = null;
        this._tooltip?.destroy();
        this._tooltip = null;
    }
}
