import St from 'gi://St';

import {Extension} from 'resource:///org/gnome/shell/extensions/extension.js';
import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import {UnlockDialog} from 'resource:///org/gnome/shell/ui/unlockDialog.js';

// FIX-040, GNOME Shell 48: only replace the lock dialog's background actor.
// Authentication, notifications, accessibility and clock remain upstream.
export default class WorkDeskLockSurface extends Extension {
    enable() {
        this._originalCreateBackground = UnlockDialog.prototype._createBackground;
        UnlockDialog.prototype._createBackground = function (monitorIndex) {
            const monitor = Main.layoutManager.monitors[monitorIndex];
            const surface = new St.Widget({
                style_class: 'screen-shield-background',
                x: monitor.x,
                y: monitor.y,
                width: monitor.width,
                height: monitor.height,
                reactive: false,
                style: 'background-color: #111e2b; ' +
                    'background-gradient-direction: vertical; ' +
                    'background-gradient-start: #23384a; ' +
                    'background-gradient-end: #0b1622;',
            });

            if (monitorIndex === Main.layoutManager.primaryIndex) {
                const brand = new St.Label({
                    text: 'WorkDesk',
                    x: Math.max(24, monitor.width - 205),
                    y: Math.max(24, monitor.height - 66),
                    style: 'color: rgba(224, 237, 246, 0.26); ' +
                        'font-size: 20px; font-weight: 600;',
                    reactive: false,
                    accessible_name: 'WorkDesk',
                });
                surface.add_child(brand);
            }

            this._backgroundGroup.add_child(surface);
        };

        // The dialog may already exist when an extension is enabled in a session.
        Main.screenShield._dialog?._updateBackgrounds();
    }

    disable() {
        if (this._originalCreateBackground) {
            UnlockDialog.prototype._createBackground = this._originalCreateBackground;
            this._originalCreateBackground = null;
        }
        Main.screenShield._dialog?._updateBackgrounds();
    }
}
