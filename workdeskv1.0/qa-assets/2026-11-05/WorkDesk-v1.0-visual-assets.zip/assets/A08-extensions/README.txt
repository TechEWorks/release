WorkDesk GNOME lock screen extension inventory — 30 October 2026

Component: Unblank lock screen
GNOME extension UUID: unblank@sun.wxg@gmail.com
Pinned extension version: 35
Target: GNOME Shell 48 on Debian 13 WorkDesk VM 211
Source: https://extensions.gnome.org/extension/1414/unblank/
Upstream code: https://github.com/sunwxg/gnome-shell-extension-unblank
Distribution file: unblank-v35.shell-extension.zip
Download URL: https://cdn.extensions.gnome.org/extension-data/unblanksun.wxggmail.com.v35.shell-extension.zip
SHA256: 48ed89923f6a72e32d19dbf48ef6474e537489c812eee591b48141238c8852bb
Licence: MIT; text preserved in unblank-MIT-LICENSE.txt and installed beside extension.js.
Deployment: ../provisioning/install-workdesk-unblank-lock-v1.sh

The extension keeps the native GNOME lock clock visible rather than immediately
blanking the display. On VM 211, User 1 and User 2 loaded the systemwide copy,
and the second user's lock remained active after 10 seconds. This does not
qualify XRDP or accounts created after deployment; test those before release.
