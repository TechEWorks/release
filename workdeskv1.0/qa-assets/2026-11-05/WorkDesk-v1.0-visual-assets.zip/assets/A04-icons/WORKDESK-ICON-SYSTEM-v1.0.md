# TechE.Works WorkDesk v1.0 icon system

Status: the v1.1 Light/Dark candidate on VM 211 includes original art for all 60 P0 names in the Debian Adwaita inventory and 51 symbolic names at five native sizes. P1/P2 coverage, full installed-surface QA, and release acceptance remain open.

## Scope and sources

The machine-readable [Adwaita name inventory](adwaita-trixie-icon-inventory-v1.0.csv) has **707 distinct names** extracted from the [Debian 13 `adwaita-icon-theme` package file list](https://packages.debian.org/trixie/all/adwaita-icon-theme/filelist). Its priorities currently comprise 60 P0, 75 P1, and 572 P2 names. The separate [cursor inventory](adwaita-trixie-cursor-inventory-v1.0.csv) contains 62 cursor names from that same package. The counts describe **this package only**. They do not enumerate every icon GNOME, installed applications, other inherited themes, or Flatpaks can request. The 31 October VM 211 [installed launcher audit](../../build/vm211-mvp-batch-20261030/workdesk-icon-audit.json) found 109 desktop entries with 95 distinct icon names: 8 resolve to TechE theme assets, 87 to inherited or vendor assets, and none are missing in either Light or Dark. Original Adwaita-inventory coverage is P0 60/60, P1 11/75 and P2 10/572. Reconcile the remaining application surfaces and inherited names before release packaging.

Use the [Freedesktop icon naming specification](https://specifications.freedesktop.org/icon-naming/0.8/) and [icon theme lookup specification](https://specifications.freedesktop.org/icon-theme/0.13/) as the integration contract. TechE artwork uses interoperable icon names; it does not copy Adwaita or Fluent drawings. The installed theme inherits from Fluent-light, Adwaita and hicolor while TechE replacements are being completed. Mark inherited icons in the release manifest so no one mistakes fallback art for TechE art.

## Visual scale at 1920 × 1080, 100%

| Surface | TechE v1.0 target | Source/validation |
| --- | --- | --- |
| Desktop and Files folder art | Shared master, approximately 52 × 47 visible px inside a 56 × 52 px box | A slightly taller, rectangular folder is in the preview. Compare actual installed screenshot at 100%. |
| Files grid | Four columns in this preview, 144 px cell width, 88 px minimum row pitch, 14 px labels | Design target, **not a proven GNOME Files setting**. Adjust actual Nautilus zoom and spacing, or revise target after the live test. |
| Panel application art | 24 × 24 px optical class in a 44 × 44 px hit area on a 48 px panel | Compare rendered colored bounds across vendor marks. |
| Symbolic/tray art | 16 × 16 px nominal | Make separate symbolic drawings; shrinking the full-color SVG is insufficient. |
| Larger source | Scalable SVG plus checked 16, 24, 32, 48, and 64 px renderings | [Windows Explorer](https://learn.microsoft.com/en-us/windows/win32/menurc/about-icons) uses 32 px medium and 48 px large/desktop shell icon classes at 96 DPI. That is a proportion reference, not a GNOME default. |

The same `workdesk-folder-v1.svg` file is used on the preview desktop and in its Files grid. The master has a taller visible face after the latest vertical adjustment. Do not make desktop and Files variants with different silhouettes; different rendered sizes can be used only when the native surface requires them.

## First drawing wave

| Family | Required names/objects | Status |
| --- | --- | --- |
| Places | `folder`, `folder-open`, desktop, home, documents, downloads, music, pictures, public, templates, videos, remote, network, bookmarks | Unique original badges for home, downloads, music, pictures, videos, public, templates, desktop, remote and bookmarks are test-deployed. `folder-open` still needs its own silhouette. |
| Trash | `user-trash`, `user-trash-full`, symbolic empty/full, restore and empty actions | Original empty/full color prototypes drawn. Symbolic and action icons pending. |
| File types | generic text, PDF/document, spreadsheet, presentation, image, audio, video, archive, executable, link, certificate | Twelve generic file-type names are test-deployed; MIME aliases and application coverage remain open. |
| Devices and network | computer, drive, removable drive, printer, server, wired, Wi-Fi, VPN, battery, audio | Original computer, network and printer drawings are test-deployed; other devices and states remain open. |
| Shell controls | Start/Applications, search, back, forward, up, view grid/list, settings, lock, power, close, minimize, maximize, restore | Original three-bar Start SVG deployed in ArcMenu on VM 211. Other 16 px symbolic icons pending. |
| Status and alerts | network and sound states, sync, notifications, warning, error, success, busy | Pending; ensure states differ by shape as well as color. |
| TechE applications | WorkDesk G2, Control Panel, theme selector, installer, support | Pending, except a preview stand-in for G2. |
| Vendor applications | Firefox, ONLYOFFICE, Thunderbird, Nextcloud, Mattermost, Open WebUI and any selected pack apps | Retain recognizable vendor marks and their licence/trademark notices; normalize optical size through padding and panel settings, without redrawing their identities as TechE marks. |
| Pointer | default, text, link, busy, move, directional resize, forbidden and remaining Xcursor aliases | VM 211 pilot has 22 original masters covering all 62 names at 24/30/36/48/72/96 px. Binary frames and hotspots passed; default and text pointers matched live X11 pixels. Clean-VM, greeter and installed-ISO checks remain. |

`start-here` should be included as a supplemental standard-name requirement even though it is absent from the Debian package list used for the CSV. App-specific icon names and symbolic names discovered on VM 211 must be added to the release manifest, not hidden in a vague “other” group.

## Packaging and live proof

1. Keep original editable SVG masters in this folder. The first installable `TechE-WorkDesk/index.theme` declares its size/context directories and inherits Fluent-light, Adwaita and hicolor. The test theme is installed on a snapshotted VM 211. Add unique special-folder, network and symbolic names to the next package revision.
2. The theme is selected via GNOME `icon-theme` and observed in Nautilus and Desktop Icons NG at 1920 × 1080. Verify Shell, Settings, dialogs and app-menu coverage independently; resolve aliases such as `inode-directory` where needed.
3. Capture real 1920 × 1080 local and XRDP screenshots with a folder on the desktop, the same folder in Files, empty and full Trash, search/menu, and a mixed-app taskbar. Verify exact visible bounds, text baselines, keyboard focus, contrast, and recognition at 16/24/32/48 px.
4. Confirm a missing TechE icon inherits a valid fallback. Log each fallback in the release manifest; the goal is a coherent pack, not a misleading claim of 707 original drawings.

## Mockup versus GNOME implementation

| Preview element | Real desktop path | Gate |
| --- | --- | --- |
| Desktop folders | [Desktop Icons NG](https://packages.debian.org/stable/gnome/gnome-shell-extension-desktop-icons-ng) displays `~/Desktop`; theme name lookup supplies folder art | Installed and enabled; current user's desktop captured. Fresh-user and XRDP checks open. |
| Files folders and Trash | Nautilus and icon theme lookup | Test names, zoom and empty/full state on VM. Exact preview grid spacing is not established. |
| Left or centered panel | Dash to Panel settings | Test both arrangements and every tooltip in a live session. |
| Transparent desktop icon labels | DING/theme styling | Test on the actual wallpaper at multiple scales. The HTML CSS alone proves nothing about DING. |
| Square window corners and compact headers | GTK/libadwaita app styling and application behavior | Audit each native window. A global mockup CSS rule cannot guarantee it. |
| Tray tooltips | GNOME Shell and extensions | Check each status item. App-icon tooltip support does not prove every system status tooltip. |
| Vendor app pins | Actual installed app launchers | Prototype placeholders are labelled in the HTML. Do not report Nextcloud, Mattermost, Open WebUI, or G2 Linux as deployed until installed and launched. |

The wallpaper, first icon theme and Start SVG are test-deployed to the snapshotted VM under the user's live-iteration instruction. Release acceptance remains open.
