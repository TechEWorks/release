TechE.Works WorkDesk v1.0 — original nature wallpaper candidates
Created 30 October 2026 with image generation from TechE art direction.
Seven distinct scenes: Alpine Dawn, Northern Lake, Dawn Dunes, Coastal
Headland, Milky Way, Cedar Forest, Highland After Storm. No Zorin image,
logo, trademark or source file was used as a generation input.

Approved composition direction: keep the left desktop-icon area visually
quiet (lower detail/texture), and put the principal landscape details on the
freer right side. This is about visual complexity, not a required left/right
brightness gradient. The current scenes largely meet that direction and are
preserved. Cedar Forest has more detail on the left; check desktop-icon label
legibility there before release. Do not mistake image-generated candidate art
for verified real photographs; a separate source/rights review is required.

All PNGs: 1672x941 (16:9). GNOME zooms them to 1920x1080 on the pilot VM;
evaluate detail/contrast after scaling on every target display. They are
candidate artwork and not a cleared ISO release set. Keep source hashes,
generation provenance and human art/rights review in the release record.

Install with assets/provisioning/install-workdesk-nature-wallpapers-v1.sh,
pointing it at this directory. It adds a separate GNOME wallpaper catalog;
stock GNOME and earlier TechE choices remain. The PNGs deliberately omit a
baked WorkDesk wordmark so a future separate, resolution-aware desktop brand
overlay can preserve the upper-right signature without multiplying artwork.
The current pilot signature was baked into the old office wallpaper, so it
is absent from these previews until that overlay is built.
